All of these project is achieved by using the Software Serial of Arduino(Bluetooth), Hardware Serial is used for debug(PC).


Debug terminal used: RealTerm
	which allow us to view as hex(space) format and send number as well as ascii to Serial.


X_LoRa_E32: connect Hardware Serial to Software Serial. Which allow you to control both E32 via the terminal to emulate sending data by hand (for observation)

X_LoRa_E32_beta: Accept "a", "b" command to send specific data to the other E32. which you can call function in the later development program.

X_LoRa_E32_loopback_Master/Slave: 
B as a loop back slave. A will send data to the B and B will immediatly return those data back to A.
Data Frame is added in this version of program since we need to know the size of recieved data.